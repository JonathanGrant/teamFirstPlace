"""
Module to control Odometry.
This is a template only and needs to be finished in Lab2
"""
import time

class Odometry:
    def __init__(self, pin): #what do we need to take in the constructor?
        self.create.leftEncoder = 43
        self.create.rightEncoder = 44
        
    def printVars():
        
        